The following scripts depend on downloading
`./AmItheAsshole_commenst.zst` and `./AmItheAsshole_submissions.zst`
from the torrent with hash: 56aa49f9653ba545f48df2e33679f014d2829c10
and putting these files in the ./data directory.

All scripts should be run when the working directory is the same as the location of this README.md file.


There is a list of all unique 'submission names' in `./data/submission-names-unique.csv`

To extract submissions from zstandard compressed file run:

`./bin/cat_submissions | python src/extract_submissions.py`

The 'submission names' of the 50,000 uniformly sampled submissions are in `./data/selected-50000.csv`.

To collect the 50,000 submissions and their comments into `./data/submissions_with_comments`
run:
`./bin/cat_comments | python src/extract_comments.py`.

The manually annotated comments are collected in `./data/manual.csv`.

In order to train the logistic regression model we need bert embeddings of the manually annotated comments which we can generated with:
`python src/man_embeddings.py`.

To run cross-validation for the animosity and thankfulness classifiers run:

`python src/manual_train_cls_thankfulness.py` and
`python src/manual_train_cls_animosity.py`

# Dataset 1 for RQ1
To create the dataset for dataset 1 we need to run:
`python src/mk_ds1_pre.py` (creates `./data/ds1-step1.csv`)
`python src/mk_ds1_valid.py` (creates `./data/ds1_subs_with_valid.csv`)
`python src/mk_ds1_grouped.py` (create `./data/ds1_counts_per_sub.csv` and `./data/ds1_grouped/*`)
`python src/mk_ds1_sample.py` (creates `./data/ds1.csv`)

To create BERT embeddings for Dataset 1 run:
`python src/ds1_embeddings_c2.py`

Finally, to label dataset for the labels of interest (`thankfulness` and `you_as_subject`), run:
`python src/ds1.py` (creates `./data/ds1-you-thank.csv`)

To run the statistical chi-square test on the labeled data run:
`Rscript src/ds1-test.r`

## Dataset 2 for RQ2

To create the dataset for dataset 2 we need to run:
`python3 src/creating_1000submissions_with_comments.py` (creates processed_comments.csv)

Dataset is divided into two parts using:
`python3 src/splittingthedataset.py` (creates processed_part1,processed_part2)

To create BERT embeddings for Dataset 2 run:
`python3 src/ds2_embeddings_1.py` (creates embeddings of part 1)
`python3 src/ds2_embeddings_2.py` (creates embeddings of part 2)

Classification (animosity):
`python3 src/ds2_animosty.py 1` (creates ds2-animosity-part1.csv)
`python3 src/ds2_animosty.py 2` (creates ds2-animosity-part2.csv)

Merge the files:
`python3 src/mergingfile` (creates data/ds2-animosity-full-version1.csv)

Creating the final file for Spearman analysis:
`python3 src/RQ2-MeCount.py`
`python3 src/Merger.py`
`python3 src/finalmergerRQ2.py` (creates processed_dataset_IME_Animosity.csv)


To run the Spearman correlation test on the labeled data run:
`python3 src/spearman.py` (results saved in ./fig)

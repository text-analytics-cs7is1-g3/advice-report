import pandas as pd
from scipy.stats import spearmanr
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
data = pd.read_csv('data/processed_dataset_IME_Animosity.csv')
data['animosity'] = pd.to_numeric(data['animosity'], errors='coerce')

data['has_downvotes'] = data['upvote'].apply(lambda x: 1 if x < 0 else 0)
data_1 = data.groupby('submission_id').agg({'I_Me_Count':'max', 'animosity':'sum', 'has_downvotes':'sum'})

# Calculate Spearman's correlation coefficient
spearman_corr_upvote = spearmanr(data_1['I_Me_Count'], data_1['has_downvotes'])
spearman_corr_animosity = spearmanr(data_1['I_Me_Count'], data_1['animosity'])

# Save correlation results to CSV
correlation_data = {
    'Correlation_Type': ['I/Me Count vs. Has Downvotes', 'I/Me Count vs. Animosity'],
    'Spearman_Correlation': [spearman_corr_upvote.correlation, spearman_corr_animosity.correlation],
    'P_Value': [spearman_corr_upvote.pvalue, spearman_corr_animosity.pvalue]
}
correlation_df = pd.DataFrame(correlation_data)
correlation_df.to_csv('fig/correlation_results.csv', index=False)

# Create scatter plots
plt.figure(figsize=(14, 6))

# Scatter plot for I/Me Count vs. Has Downvotes
plt.subplot(1, 2, 1)
sns.scatterplot(x=data_1['I_Me_Count'], y=data_1['has_downvotes'], alpha=0.5)
plt.title(f"I/Me Count vs. Has Downvotes (Spearman Correlation: {spearman_corr_upvote.correlation:.3f})")
plt.xlabel('I/Me Count')
plt.ylim(0, 50)  # Adjust based on your data
plt.ylabel('Has Downvotes')

# Save the first plot
plt.tight_layout()
plt.savefig('fig/I_Me_vs_Has_Downvotes.png')

# Scatter plot for I/Me Count vs. Animosity
plt.subplot(1, 2, 2)
sns.scatterplot(x=data_1['I_Me_Count'], y=data_1['animosity'], alpha=0.5)
plt.title(f"I/Me Count vs. Animosity (Spearman Correlation: {spearman_corr_animosity.correlation:.3f})")
plt.xlabel('I/Me Count')
plt.ylim(0, 500)  # Adjust based on your data
plt.ylabel('Animosity')

# Save the second plot and show
plt.tight_layout()
plt.savefig('fig/I_Me_vs_Animosity.png')
plt.show()

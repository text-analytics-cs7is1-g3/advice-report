import pandas as pd

# Load two datasets
file_path1 = 'data/processed_comments.csv'
file_path2 = 'data/submissions_with_IMeCount.csv'

data1 = pd.read_csv(file_path1)
data2 = pd.read_csv(file_path2)

# Ensure 'submission_id' is the key for joining
data1.set_index('submission_id', inplace=True)
data2.set_index('submission_id', inplace=True)

# Merge the dataframes on 'submission_id', pulling 'I_Me_Ratio' from the second dataset
result = data1.join(data2['I_Me_Count'], how='left')

# Reset the index if needed (optional, depends on whether you want to keep 'submission_id' as the index)
result.reset_index(inplace=True)

# Save the updated dataframe to a new CSV file (optional)
output_file_path = 'data/processed_dataset_IME.csv'
result.to_csv(output_file_path, index=False)

# Print confirmation that the file has been saved (optional)
print(f"File has been saved to {output_file_path}")

import pandas as pd

# Load the CSV file
data = pd.read_csv("data/processed_comments.csv")

# Split the data into two halves
half_len = len(data) // 2
first_half = data.iloc[:half_len]
second_half = data.iloc[half_len:]

# Store each half into separate CSV files
first_half.to_csv("data/processed_part1.csv", index=False)
second_half.to_csv("data/processed_part2.csv", index=False)

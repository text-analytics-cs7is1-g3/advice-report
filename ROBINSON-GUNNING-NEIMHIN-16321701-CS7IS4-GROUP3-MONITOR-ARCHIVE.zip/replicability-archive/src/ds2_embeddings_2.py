import pandas as pd
import json
import bert_cls
import os
import torch
import time
import sys

# Create the directory for embeddings if it does not already exist.
os.makedirs("data/ds2-embeddings-part2/", exist_ok=True)
chunksize = 128
dfi = pd.read_csv("data/processed_part2.csv", chunksize=chunksize)


def id2filename(i):
    return f"data/ds2-embeddings-part2/{i}.pt"


for df in dfi:
    t0 = time.perf_counter()

    # Update IDs and bodies.
    df["id"] = df["comment_id"]
    df["body"] = df["comment_body"]

    # Remove entries with NaN in 'body'.
    initial_count = len(df)
    df = df.dropna(subset=["body"])
    removed_count = initial_count - len(df)
    if removed_count > 0:
        print(f"Removed {removed_count} entries due to NaN body")

    # Generate embeddings for non-empty, non-NaN bodies.
    if len(df) > 0:
        inputs = df["body"].tolist()
        embeddings = bert_cls.four_layer_embeddings(inputs)

        for i in range(len(df)):
            row = df.iloc[i]
            filename = id2filename(row["id"])
            if os.path.exists(filename):
                print(f"Skipped {row['id']} as embedding already exists")
                continue
            embedding = embeddings[i, :]
            torch.save(embedding, filename)
            print(".", end="", flush=True)
    else:
        print("No valid entries to process in this chunk.")

    t1 = time.perf_counter()
    print(f"\nsaved {len(df)} embeddings in {t1 - t0:.0f} seconds")

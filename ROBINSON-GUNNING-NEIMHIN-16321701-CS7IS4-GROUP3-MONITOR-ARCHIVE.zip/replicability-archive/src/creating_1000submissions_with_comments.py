import json
import pandas as pd

def load_submission_and_comments(name):
    fname = f"data/submissions_with_comments/{name}"
    with open(fname, "r") as f:
        line = f.readline()
        submission = json.loads(line)
        comments = []
        while line:
            line = f.readline()
            if line:
                comments.append(json.loads(line))
        return [submission, comments]

# Load the CSV file
input_file = 'data/random-1000.csv'

# Read the CSV into a DataFrame
data = pd.read_csv(input_file)

# Prepare a list to collect all rows for the final DataFrame
rows = []

# Process each file reference in the data DataFrame
for index, row in data.iterrows():
    submission, comments = load_submission_and_comments(row[1])
    for comment in comments:
        # Check if the comment is neither deleted nor removed
        if comment.get('body', '') not in ['[removed]', '[deleted]']:
            row_data = {
                'submission_id': submission.get('name', ''),
                'submission_body': submission.get('selftext', ''),
                'comment_id': comment.get('id', ''),
                'comment_body': comment.get('body', ''),
                'upvote': comment.get('upvote_ratio', ''),
                'downvote': comment.get('downs', '')
            }
            rows.append(row_data)

# Convert the list of rows to a DataFrame
result_df = pd.DataFrame(rows)

# Save the DataFrame to a CSV file
output_file = 'data/processed_comments.csv'
result_df.to_csv(output_file, index=False)

# Load the processed data to find unique submission IDs
unique_submission_ids = result_df['comment_id'].unique()

# Print the unique submission IDs and count
print("Number of unique comments:", len(rows))
print("Unique Submission IDs:")
print(unique_submission_ids)
print("Number of Unique Submission IDs:", len(unique_submission_ids))

import pandas as pd
import re

# Load the CSV file
file_path = 'data/processed_comments.csv'
data = pd.read_csv(file_path)

# Keep only the first two columns
reduced_data = data[['submission_id', 'submission_body']]

# Remove duplicate entries
unique_data = reduced_data.drop_duplicates()

# Function to calculate the count of "I" and "Me" in the text
def calculate_ratio(text):
    if pd.isna(text):
        return 0  # In case of NaN entries, return 0
    word_list = re.findall(r'\b\w+\b', text)  # Extract all words using regex
    count_i_me = sum(1 for word in word_list if word.lower() in ['i', 'me'])
    return count_i_me  # Return count

# Apply the function to each row in the 'submission_body' column
unique_data['I_Me_Count'] = unique_data['submission_body'].apply(calculate_ratio)

# Save the updated dataframe to a new CSV file
output_file_path = 'data/submissions_with_IMeCount.csv'
unique_data.to_csv(output_file_path, index=False)

# Print confirmation that the file has been saved
print(f"File has been saved to {output_file_path}")


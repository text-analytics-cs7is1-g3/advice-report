import pandas as pd

# Load the first CSV file
df1 = pd.read_csv('data/ds2-animosity-part1.csv')

# Load the second CSV file
df2 = pd.read_csv('data/ds2-animosity-part2.csv')

# Append the rows of the second dataframe to the first dataframe
merged_df = pd.concat([df1, df2], ignore_index=True)

# Store the merged dataframe in another CSV file
merged_df.to_csv('data/ds2-animosity-full-version1.csv', index=False)
